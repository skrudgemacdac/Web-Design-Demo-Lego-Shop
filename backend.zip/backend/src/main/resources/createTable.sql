-- PostgreSQL schema for the e-commerce.
-- Run this file against your DB (ecommdb) to create the required tables and relationships.
-- Note: Spring JPA can still run with ddl-auto=update, but this file provides a clean baseline schema.

-- Drop in dependency order
DROP TABLE IF EXISTS order_items CASCADE;
DROP TABLE IF EXISTS orders CASCADE;
DROP TABLE IF EXISTS cart_items CASCADE;
DROP TABLE IF EXISTS wishlist_items CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS products CASCADE;

-- =============
-- Core entities
-- =============

CREATE TABLE users (
    id              BIGSERIAL PRIMARY KEY,
    email           VARCHAR(255) NOT NULL UNIQUE,
    full_name       VARCHAR(255),
    password_hash   VARCHAR(255),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE products (
    id              BIGSERIAL PRIMARY KEY,
    name            VARCHAR(255)   NOT NULL,
    description     TEXT,
    price           NUMERIC(10, 2) NOT NULL CHECK (price >= 0),
    currency        CHAR(3)        NOT NULL DEFAULT 'USD',

    -- Images: can be a local path (served from backend) or a full URL.
    image_url       VARCHAR(1024),

    -- Fields used by the frontend (filters / badges)
    category        VARCHAR(64),
    age_range       VARCHAR(32),
    details_count   INT CHECK (details_count IS NULL OR details_count >= 0),

    featured        BOOLEAN        NOT NULL DEFAULT FALSE,
    details         TEXT,

    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_products_featured ON products(featured);
CREATE INDEX idx_products_category ON products(category);

-- ======================
-- Wishlist (User <-> Product)
-- ======================

CREATE TABLE wishlist_items (
    user_id     BIGINT NOT NULL,
    product_id  BIGINT NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    PRIMARY KEY (user_id, product_id),
    CONSTRAINT fk_wishlist_user
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_wishlist_product
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE INDEX idx_wishlist_product ON wishlist_items(product_id);

-- ==================
-- Cart (User <-> Product)
-- ==================

CREATE TABLE cart_items (
    user_id     BIGINT NOT NULL,
    product_id  BIGINT NOT NULL,
    quantity    INT NOT NULL DEFAULT 1 CHECK (quantity > 0),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    PRIMARY KEY (user_id, product_id),
    CONSTRAINT fk_cart_user
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_cart_product
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
);

CREATE INDEX idx_cart_product ON cart_items(product_id);

-- ==============
-- Orders
-- ==============

CREATE TABLE orders (
    id              BIGSERIAL PRIMARY KEY,
    user_id         BIGINT,

    status          VARCHAR(32) NOT NULL DEFAULT 'NEW', -- NEW, PAID, SHIPPED, CANCELLED
    currency        CHAR(3)     NOT NULL DEFAULT 'USD',
    total_amount    NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (total_amount >= 0),

    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT fk_orders_user
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE INDEX idx_orders_user ON orders(user_id);
CREATE INDEX idx_orders_status ON orders(status);

CREATE TABLE order_items (
    id              BIGSERIAL PRIMARY KEY,
    order_id        BIGINT NOT NULL,
    product_id      BIGINT,

    product_name    VARCHAR(255),
    unit_price      NUMERIC(10, 2) NOT NULL DEFAULT 0 CHECK (unit_price >= 0),
    quantity        INT NOT NULL DEFAULT 1 CHECK (quantity > 0),
    line_total      NUMERIC(12, 2) NOT NULL DEFAULT 0 CHECK (line_total >= 0),

    CONSTRAINT fk_order_items_order
        FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    CONSTRAINT fk_order_items_product
        FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
);

CREATE INDEX idx_order_items_order ON order_items(order_id);
CREATE INDEX idx_order_items_product ON order_items(product_id);
