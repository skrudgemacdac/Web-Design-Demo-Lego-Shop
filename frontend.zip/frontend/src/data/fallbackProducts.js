// Shared fallback products used when the backend API is unavailable.
// Keep this list in sync with what you want to display in the catalog/demo.
export const fallbackProducts = [
  {
    id: 1,
    name: "Airport fire truck",
    description:
      "Build the LEGO® City Airport Fire Truck (60499) for kids ages 7 and up. This realistic fire rescue toy features a 360° rotating fire extinguisher on the roof, opening side compartments for equipment, and tool storage. Kids can turn the handle to steer the truck, fire the water from the extinguisher, and remove the engine for repairs.",
    price: 4990,
    category: "LEGO CITY",
    age: "6-10 years",
    detailsCount: 509,
    img: "https://mir-kubikov.ru/upload/resize_cache/iblock/e86/746_580_1/9cmtuimyppawh6hknclp8bkfm03759fp.jpg",
  },
  {
    id: 2,
    name: "Bugatti Chiron Pur Sport",
    description:
      "The LEGO® TECHNIC Bugatti Chiron Pur Sport (42222) is a detailed LEGO TECHNIC set dedicated to the legendary Bugatti Chiron Pur Sport supercar. The LEGO® TECHNIC Bugatti Chiron Pur Sport set allows you to build a realistic model with movable parts, opening up possibilities for exciting arcade games and display scenes.",
    price: 6990,
    category: "LEGO TECHNIC",
    age: "8-12 years",
    detailsCount: 780,
    img: "https://static.mir-kubikov.ru/upload/iblock/aaa/x1_310-230-k9k8j0sdvvpr5usggyellwqmiaq2nykc.jpg",
  },
  {
    id: 3,
    name: "Airplane, service truck and hovercraft",
    description:
      "Inspire creative play with the LEGO® City Airplane, Utility Truck, and Hovercraft (60505) set for ages 7 and up. This 3-piece rescue vehicle set features a medical plane, a Coast Guard hovercraft, and a utility truck with a lifting boom.",
    price: 3290,
    category: "LEGO CITY",
    age: "6-10 years",
    detailsCount: 420,
    img: "https://mir-kubikov.ru/upload/resize_cache/iblock/c4e/746_580_1/5pb30oc1o29ekgytvyq6fyw1jz1pkini.jpg",
  },
  {
    id: 4,
    name: "Etihad Stadium",
    description:
      "Immerse yourself in the world of football with the CaDa Etihad Stadium (C66022W) construction set, created under official Manchester City license! Opened in 2003, Etihad Stadium is one of the most modern football complexes in England. It seats over 53,000 spectators and is home to one of the world's top clubs, Manchester City.",
    price: 3290,
    category: "LEGO CITY",
    age: "6-10 years",
    detailsCount: 4473,
    img: "https://mir-kubikov.ru/upload/resize_cache/iblock/af8/746_580_1/n1u3zj12g2kc29m9q4narzlcbjwf8j75.jpg",
  },
];


