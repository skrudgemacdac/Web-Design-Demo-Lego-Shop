import React from "react";
import { Heart } from "lucide-react";
import { Link } from "react-router-dom";
import { useCart } from "../../context/CartContext";
import { useWishlist } from "../../context/WishlistContext";
import { resolveImageUrl } from "../../config";

import "./ProductCard.css";

export default function ProductCard({ product }) {
  const { add } = useCart();
  const { toggle, isInWishlist } = useWishlist();
  const inWishlist = isInWishlist(product.id);

  const formattedPrice =
    typeof product.price === "number"
      ? new Intl.NumberFormat("en-US", {
          style: "currency",
          currency: "USD",
          maximumFractionDigits: 0,
        }).format(product.price)
      : product.price || "—";

  const imageUrl = product.imageUrl ? resolveImageUrl(product.imageUrl) : null;
  const imageSrc = imageUrl || product.img || null;

  return (
    <div className="lego-card">
      <div className="lego-card__media">
        {imageSrc ? (
          <img src={imageSrc} alt={product.name} loading="lazy" />
        ) : (
          <div className="lego-card__placeholder">🧱</div>
        )}
        <button
          type="button"
          className={`lego-card__favorite ${inWishlist ? "lego-card__favorite--active" : ""}`}
          aria-label={inWishlist ? "Remove from wishlist" : "Add to wishlist"}
          onClick={() => toggle(product)}
        >
          <Heart size={20} />
        </button>
      </div>

      <div className="lego-card__content">
        <div className="lego-card__category">{product.category || "LEGO CITY"}</div>
        <h3 className="lego-card__title">{product.name}</h3>
        <p className="lego-card__description">{product.description}</p>
        <div className="lego-card__meta">
          <span className="lego-card__tag">{product.age || "6+ years"}</span>
          <span className="lego-card__meta-text">
            {product.detailsCount ? `${product.detailsCount} pieces` : "Lots of pieces"}
          </span>
        </div>
      </div>

      <div className="lego-card__footer">
        <span className="lego-card__price">{formattedPrice}</span>
        <div className="lego-card__actions">
          <button type="button" className="lego-card__button" onClick={() => add(product)}>
            Add to cart
          </button>
          <Link className="lego-card__link" to={`/products/${product.id}`}>
            Details
          </Link>
        </div>
      </div>
    </div>
  );
}

