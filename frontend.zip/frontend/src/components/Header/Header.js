import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Heart, Home, Search, ShoppingCart, User } from "lucide-react";
import { TextField, InputAdornment } from "@mui/material";
import { useCart } from "../../context/CartContext";
import { useWishlist } from "../../context/WishlistContext";
import { useSearch } from "../../context/SearchContext";

import "./Header.css";

export default function Header() {
  const { items } = useCart();
  const { items: wishlistItems } = useWishlist();
  const { setQuery } = useSearch();
  const [search, setSearch] = useState("");

  const totalCount = items.reduce(
    (sum, it) => sum + (it.quantity || 1),
    0
  );

  const wishlistCount = wishlistItems.length;

  useEffect(() => {
    const id = setTimeout(() => {
      setQuery(search.trim());
    }, 500);
    return () => clearTimeout(id);
  }, [search, setQuery]);

  return (
    <header className="lego-header">
      <div className="lego-header__inner">
        <div className="lego-header__brand">
          <Link to="/" className="lego-header__logo" aria-label="LEGO">
            <span className="lego-header__logo-mark" aria-hidden="true" />
            <span className="sr-only">LEGO</span>
          </Link>
          <nav className="lego-header__nav">
            <Link className="lego-header__link" to="/">
              <Home size={16} />
              <span>Home</span>
            </Link>
            <Link className="lego-header__link" to="/about">
              <span>About</span>
            </Link>
            <Link className="lego-header__link" to="/contacts">
              <span>Contacts</span>
            </Link>
          </nav>
        </div>

        <div className="lego-header__actions">
          <TextField
            className="lego-header__search"
            size="small"
            placeholder="Search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <Search size={18} color="#fff" />
                </InputAdornment>
              ),
            }}
          />
          <Link className="lego-header__icon-btn" to="/wishlist" aria-label="Wishlist">
            {wishlistCount > 0 && <span className="lego-header__badge">{wishlistCount}</span>}
            <Heart size={20} />
          </Link>
          <Link className="lego-header__icon-btn" to="/checkout" aria-label="Cart">
            {totalCount > 0 && <span className="lego-header__badge">{totalCount}</span>}
            <ShoppingCart size={20} />
          </Link>
          <Link className="lego-header__icon-btn" to="/register" aria-label="Account">
            <User size={20} />
          </Link>
        </div>
      </div>
    </header>
  );
}

