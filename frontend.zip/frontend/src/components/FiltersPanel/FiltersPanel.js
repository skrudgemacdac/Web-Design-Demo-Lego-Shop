import React from "react";
import { Filter } from "lucide-react";
import { FormControl, InputLabel, MenuItem, Select } from "@mui/material";

import "./FiltersPanel.css";

const ageOptions = [
  { value: "all", label: "All ages" },
  { value: "4-7", label: "4-7 years" },
  { value: "8-12", label: "8-12 years" },
  { value: "13+", label: "13+ years" },
];

const priceOptions = [
  { value: "any", label: "Any" },
  { value: "lt-2000", label: "Under $2,000" },
  { value: "2000-5000", label: "$2,000–$5,000" },
  { value: "gt-5000", label: "Over $5,000" },
];

const seriesOptions = [
  { value: "all", label: "All series" },
  { value: "city", label: "City" },
  { value: "technic", label: "Technic" },
  { value: "friends", label: "Friends" },
];

const piecesOptions = [
  { value: "any", label: "Any" },
  { value: "lt-500", label: "Under 500" },
  { value: "500-1000", label: "500-1000" },
  { value: "gt-1000", label: "1000+" },
];

export default function FiltersPanel({ filters, onChange }) {
  const handleChange = (key) => (event) => {
    onChange(key, event.target.value);
  };

  return (
    <section className="lego-filters" id="catalog">
      <div className="lego-filters__header">
        <Filter size={20} />
        <h2>Filters</h2>
      </div>

      <div className="lego-filters__grid">
        <div className="lego-filters__field">
          <FormControl fullWidth size="small">
            <InputLabel id="filter-age-label">Age</InputLabel>
            <Select
              labelId="filter-age-label"
              value={filters.age}
              label="Age"
              onChange={handleChange("age")}
            >
              {ageOptions.map((opt) => (
                <MenuItem key={opt.value} value={opt.value}>
                  {opt.label}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </div>

        <div className="lego-filters__field">
          <FormControl fullWidth size="small">
            <InputLabel id="filter-price-label">Price</InputLabel>
            <Select
              labelId="filter-price-label"
              value={filters.price}
              label="Price"
              onChange={handleChange("price")}
            >
              {priceOptions.map((opt) => (
                <MenuItem key={opt.value} value={opt.value}>
                  {opt.label}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </div>

        <div className="lego-filters__field">
          <FormControl fullWidth size="small">
            <InputLabel id="filter-series-label">Series</InputLabel>
            <Select
              labelId="filter-series-label"
              value={filters.series}
              label="Series"
              onChange={handleChange("series")}
            >
              {seriesOptions.map((opt) => (
                <MenuItem key={opt.value} value={opt.value}>
                  {opt.label}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </div>

        <div className="lego-filters__field">
          <FormControl fullWidth size="small">
            <InputLabel id="filter-pieces-label">Pieces</InputLabel>
            <Select
              labelId="filter-pieces-label"
              value={filters.pieces}
              label="Pieces"
              onChange={handleChange("pieces")}
            >
              {piecesOptions.map((opt) => (
                <MenuItem key={opt.value} value={opt.value}>
                  {opt.label}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </div>
      </div>
    </section>
  );
}

