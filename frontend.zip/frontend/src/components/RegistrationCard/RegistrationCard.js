import React from "react";
import { User } from "lucide-react";

import "./RegistrationCard.css";

export default function RegistrationCard() {
  return (
    <section className="lego-register" id="register">
      <div className="lego-register__avatar">
        <User size={32} />
      </div>
      <div className="lego-register__content">
        <h3>Sign up</h3>
        <p>Create an account and get 10% off</p>

        <form className="lego-register__form">
          <input type="text" placeholder="Name" />
          <input type="email" placeholder="Email" />
          <input type="password" placeholder="Password" />
          <button type="button">Create account</button>
        </form>
      </div>
    </section>
  );
}

