import React from "react";
import { Link } from "react-router-dom";
import Container from "@mui/material/Container";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";

import ProductCard from "../components/ProductCard/ProductCard";
import { useWishlist } from "../context/WishlistContext";

import "./Wishlist.css";

export default function Wishlist() {
  const { items } = useWishlist();

  return (
    <Container sx={{ py: 4 }}>
      <div className="wishlist__header">
        <div>
          <p className="lego-store__eyebrow">Wishlist</p>
          <Typography variant="h4" component="h1" gutterBottom>
            Your wishlist
          </Typography>
          <Typography variant="body1" color="text.secondary">
            Save items you like so you can come back to them later.
          </Typography>
        </div>
        <Button component={Link} to="/" variant="outlined">
          Back to catalog
        </Button>
      </div>

      {items.length === 0 ? (
        <div className="wishlist__empty">
          <Typography variant="h6" gutterBottom>
            Nothing here yet
          </Typography>
          <Typography variant="body2" color="text.secondary">
            Add items to your wishlist using the heart icon on the product card.
          </Typography>
          <Button sx={{ mt: 2 }} component={Link} to="/" variant="contained">
            Browse products
          </Button>
        </div>
      ) : (
        <div className="lego-store__grid wishlist__grid">
          {items.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </Container>
  );
}

