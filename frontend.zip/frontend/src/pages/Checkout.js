import React from "react";
import { useCart } from "../context/CartContext";
import Container from "@mui/material/Container";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Button from "@mui/material/Button";
import Divider from "@mui/material/Divider";
import CardMedia from "@mui/material/CardMedia";
import Paper from "@mui/material/Paper";
import IconButton from "@mui/material/IconButton";
import AddIcon from "@mui/icons-material/Add";
import RemoveIcon from "@mui/icons-material/Remove";
import DeleteIcon from "@mui/icons-material/Delete";
import { resolveImageUrl } from "../config";
import { Link } from "react-router-dom";

export default function Checkout() {
  const { items, add, decrement, remove, clear } = useCart();

  const totalPrice = items.reduce(
    (sum, it) => sum + it.price * (it.quantity || 1),
    0
  );

  if (items.length === 0) {
    return (
      <Container sx={{ py: 4 }}>
        <Typography variant="h4" gutterBottom>
          Your cart is empty
        </Typography>
        <Button variant="contained" component={Link} to="/">
          Go back to shopping
        </Button>
      </Container>
    );
  }

  return (
    <Container sx={{ py: 4 }}>
      <Typography variant="h4" gutterBottom>
        Checkout
      </Typography>

      <Box sx={{ mb: 2 }}>
        <Button color="secondary" onClick={clear}>
          Clear cart
        </Button>
      </Box>

      <Divider sx={{ mb: 2 }} />

      {items.map((item) => (
        <Box key={item.id} sx={{ mb: 2 }}>
          <Grid container alignItems="center" spacing={2}>
            <Grid item xs={12} sm={2}>
              {item.imageUrl || item.img ? (
                <CardMedia
                  component="img"
                  image={item.imageUrl ? resolveImageUrl(item.imageUrl) : item.img}
                  alt={item.name}
                  sx={{
                    height: 90,
                    width: 120,
                    objectFit: "cover",
                    borderRadius: 2,
                    background: "linear-gradient(135deg, #bfdbfe, #ede9fe)",
                  }}
                />
              ) : (
                <Paper
                  elevation={1}
                  sx={{
                    height: 90,
                    width: 120,
                    borderRadius: 2,
                    background: "linear-gradient(135deg, #bfdbfe, #ede9fe)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 42,
                  }}
                >
                  🧱
                </Paper>
              )}
            </Grid>
            <Grid item xs={12} sm={4}>
              <Typography variant="subtitle1">{item.name}</Typography>
              <Typography variant="body2" color="text.secondary">
                ${item.price.toFixed(2)} each
              </Typography>
            </Grid>
            <Grid
              item
              xs={12}
              sm={3}
              sx={{ display: "flex", alignItems: "center", gap: 1 }}
            >
              <IconButton onClick={() => decrement(item.id)}>
                <RemoveIcon />
              </IconButton>
              <Typography>{item.quantity || 1}</Typography>
              <IconButton onClick={() => add(item)}>
                <AddIcon />
              </IconButton>
            </Grid>
            <Grid item xs={8} sm={2}>
              <Typography variant="subtitle1">
                ${(item.price * (item.quantity || 1)).toFixed(2)}
              </Typography>
            </Grid>
            <Grid item xs={4} sm={1}>
              <IconButton onClick={() => remove(item.id)}>
                <DeleteIcon />
              </IconButton>
            </Grid>
          </Grid>
          <Divider sx={{ mt: 2 }} />
        </Box>
      ))}

      <Box
        sx={{
          mt: 3,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "wrap",
          gap: 2,
        }}
      >
        <Typography variant="h5">
          Total: ${totalPrice.toFixed(2)}
        </Typography>
        <Button
          variant="contained"
          size="large"
          onClick={() => {
            alert("Proceeding to payment… (not implemented)");
          }}
        >
          Proceed
        </Button>
      </Box>
    </Container>
  );
}
