import React from "react";
import Container from "@mui/material/Container";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemText from "@mui/material/ListItemText";

export default function About() {
  return (
    <Container sx={{ py: 4 }}>
      <Typography variant="h4" gutterBottom>
        About us
      </Typography>
      <Typography variant="body1" color="text.secondary" paragraph>
        We love LEGO and curate great sets for kids and adults — from classic City to advanced
        Technic. Fast delivery, fair prices, and support if you need help choosing a set.
      </Typography>

      <Box sx={{ mt: 2 }}>
        <Typography variant="h6" gutterBottom>
          Why choose us
        </Typography>
        <List dense>
          <ListItem>
            <ListItemText primary="Official sets and the latest releases" />
          </ListItem>
          <ListItem>
            <ListItemText primary="Filtering by age, series, and piece count" />
          </ListItem>
          <ListItem>
            <ListItemText primary="Perks for signing up and returning customers" />
          </ListItem>
        </List>
      </Box>
    </Container>
  );
}

