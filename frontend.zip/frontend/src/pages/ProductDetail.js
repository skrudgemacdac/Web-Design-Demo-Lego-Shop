// src/pages/ProductDetail.js
import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useCart } from "../context/CartContext";
import { resolveImageUrl } from "../config";
import { getProductById } from "../services/productService";
import { fallbackProducts } from "../data/fallbackProducts";

import Container from "@mui/material/Container";
import Grid from "@mui/material/Grid";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box";
import CardMedia from "@mui/material/CardMedia";

export default function ProductDetail() {
  const { id } = useParams();
  const { add } = useCart();

  const [product, setProduct] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    setError(null);

    const numericId = Number(id);

    getProductById(numericId)
      .then((data) => {
        if (!mounted) return;
        if (data) {
          setProduct(data);
          setLoading(false);
          return;
        }
        const fallback = fallbackProducts.find((p) => Number(p.id) === numericId) || null;
        setProduct(fallback);
        if (!fallback) setError("Product not found");
        setLoading(false);
      })
      .catch(() => {
        if (!mounted) return;
        const fallback = fallbackProducts.find((p) => Number(p.id) === numericId) || null;
        setProduct(fallback);
        if (!fallback) setError("Product not found");
        setLoading(false);
      });

    return () => {
      mounted = false;
    };
  }, [id]);

  if (loading) {
    return (
      <Container sx={{ py: 4 }}>
        <Typography variant="h5" gutterBottom>
          Loading...
        </Typography>
      </Container>
    );
  }

  if (error || !product) {
    return (
      <Container sx={{ py: 4 }}>
        <Typography variant="h5" color="error" gutterBottom>
          Could not load product.
        </Typography>
        {error && (
          <Typography variant="body2" color="text.secondary" paragraph>
            {String(error)}
          </Typography>
        )}
        <Button variant="contained" component={Link} to="/">
          Back to Home
        </Button>
      </Container>
    );
  }

  const formattedPrice =
    typeof product.price === "number"
      ? new Intl.NumberFormat("en-US", {
          style: "currency",
          currency: "USD",
          maximumFractionDigits: 2,
        }).format(product.price)
      : String(product.price || "");

  const imageSrc = product.imageUrl
    ? resolveImageUrl(product.imageUrl)
    : product.img || null;

  return (
    <Container sx={{ py: 4 }}>
      <Grid container spacing={4}>
        {/* Left: main image */}
        <Grid item xs={12} md={5}>
          {imageSrc ? (
            <CardMedia
              component="img"
              image={imageSrc}
              alt={product.name}
              sx={{
                width: "100%",
                maxHeight: 400,
                objectFit: "contain",
                borderRadius: 2,
                boxShadow: 1,
                background: "linear-gradient(135deg, #bfdbfe, #ede9fe)",
              }}
            />
          ) : (
            <Box
              sx={{
                width: "100%",
                height: 320,
                borderRadius: 2,
                boxShadow: 1,
                background: "linear-gradient(135deg, #bfdbfe, #ede9fe)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: 72,
              }}
            >
              🧱
            </Box>
          )}
        </Grid>

        {/* Right: details */}
        <Grid item xs={12} md={7}>
          <Typography variant="h4" gutterBottom>
            {product.name}
          </Typography>

          <Typography variant="h6" color="primary" gutterBottom>
            {formattedPrice}
          </Typography>

          {product.description && (
            <Typography variant="body1" paragraph>
              {product.description}
            </Typography>
          )}

          {product.details && (
            <Typography variant="body2" color="text.secondary" paragraph>
              {product.details}
            </Typography>
          )}

          <Box sx={{ mt: 3, display: "flex", gap: 2, flexWrap: "wrap" }}>
            <Button
              variant="contained"
              size="large"
              onClick={() => add(product)}
            >
              Add to cart
            </Button>
            <Button
              variant="outlined"
              size="large"
              component={Link}
              to="/"
            >
              Back to Home
            </Button>
          </Box>
        </Grid>
      </Grid>
    </Container>
  );
}
