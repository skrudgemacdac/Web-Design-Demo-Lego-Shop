import React from "react";
import Container from "@mui/material/Container";
import Typography from "@mui/material/Typography";
import RegistrationCard from "../components/RegistrationCard/RegistrationCard";

export default function Register() {
  return (
    <Container sx={{ py: 4 }}>
      <Typography variant="h4" gutterBottom>
        Create an account
      </Typography>
      <Typography variant="body1" color="text.secondary" paragraph>
        Create an account to save your wishlist and get personalized offers.
      </Typography>
      <RegistrationCard />
    </Container>
  );
}



