import React, { useEffect, useMemo, useState } from "react";
import FiltersPanel from "../components/FiltersPanel/FiltersPanel";
import ProductCard from "../components/ProductCard/ProductCard";
import { getAllProducts } from "../services/productService";
import { useSearch } from "../context/SearchContext";
import { fallbackProducts } from "../data/fallbackProducts";
import "./Home.css";

export default function Home() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    age: "all",
    price: "any",
    series: "all",
    pieces: "any",
  });
  const { query } = useSearch();

  useEffect(() => {
    let mounted = true;

    getAllProducts()
      .then((data) => {
        if (mounted) {
          setProducts(Array.isArray(data) ? data : []);
          setLoading(false);
        }
      })
      .catch(() => {
        if (mounted) setLoading(false);
      });

    return () => {
      mounted = false;
    };
  }, []);

  const normalizedQuery = query.trim().toLowerCase();

  const baseProducts = products.length ? products : fallbackProducts;

  const filteredProducts = useMemo(() => {
    const parseAge = (ageStr) => {
      if (!ageStr) return { min: 0, max: Infinity };
      const nums = (ageStr.match(/\d+/g) || []).map(Number);
      if (nums.length === 0) return { min: 0, max: Infinity };
      if (nums.length === 1) return { min: nums[0], max: Infinity };
      return { min: nums[0], max: nums[1] };
    };

    const matchesAge = (product) => {
      if (filters.age === "all") return true;
      const range = parseAge(product.age);
      const sel =
        filters.age === "4-7"
          ? { min: 4, max: 7 }
          : filters.age === "8-12"
          ? { min: 8, max: 12 }
          : { min: 13, max: Infinity };
      return !(range.max < sel.min || range.min > sel.max);
    };

    const matchesPrice = (product) => {
      if (filters.price === "any") return true;
      const price = Number(product.price);
      if (Number.isNaN(price)) return true;
      switch (filters.price) {
        case "lt-2000":
          return price < 2000;
        case "2000-5000":
          return price >= 2000 && price <= 5000;
        case "gt-5000":
          return price > 5000;
        default:
          return true;
      }
    };

    const matchesSeries = (product) => {
      if (filters.series === "all") return true;
      const cat = (product.category || "").toLowerCase();
      return cat.includes(filters.series.toLowerCase());
    };

    const matchesPieces = (product) => {
      if (filters.pieces === "any") return true;
      const count = Number(product.detailsCount);
      if (Number.isNaN(count)) return true;
      switch (filters.pieces) {
        case "lt-500":
          return count < 500;
        case "500-1000":
          return count >= 500 && count <= 1000;
        case "gt-1000":
          return count > 1000;
        default:
          return true;
      }
    };

    return baseProducts.filter((item) => {
      const haystack = `${item.name} ${item.description || ""}`.toLowerCase();
      const matchesSearch = normalizedQuery ? haystack.includes(normalizedQuery) : true;
      return (
        matchesSearch &&
        matchesAge(item) &&
        matchesPrice(item) &&
        matchesSeries(item) &&
        matchesPieces(item)
      );
    });
  }, [baseProducts, normalizedQuery, filters]);

  const showProducts = filteredProducts;

  const hasResults = showProducts.length > 0;

  const handleFiltersChange = (key, value) => {
    setFilters((prev) => ({ ...prev, [key]: value }));
  };

  return (
    <div>
      <div className="lego-store__content">
        <div className="lego-store__intro" id="about">
          <div>
            <p className="lego-store__eyebrow">Sets catalog</p>
          </div>
        </div>

        <FiltersPanel filters={filters} onChange={handleFiltersChange} />

        {loading ? (
          <div className="lego-store__loader">Loading catalog...</div>
        ) : !hasResults ? (
          <div className="lego-store__empty">No results found</div>
        ) : (
          <div className="lego-store__grid">
            {showProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}

      </div>
    </div>
  );
}
