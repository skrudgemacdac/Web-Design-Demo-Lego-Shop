import React from "react";
import Container from "@mui/material/Container";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
import Paper from "@mui/material/Paper";

const contacts = [
  { label: "Phone", value: "+7 (900) 123-45-67" },
  { label: "Email", value: "support@lego-store.demo" },
  { label: "Address", value: "Kocatepe, Paşa Cd No: 3" },
  { label: "Hours", value: "Daily 10:00–21:00" },
];

export default function Contacts() {
  return (
    <Container sx={{ py: 4 }}>
      <Typography variant="h4" gutterBottom>
        Contacts
      </Typography>
      <Typography variant="body1" color="text.secondary" paragraph>
        Contact us by phone or email — we’ll help you choose a set and answer any questions.
      </Typography>

      <Grid container spacing={2} sx={{ mt: 1 }}>
        {contacts.map((item) => (
          <Grid item xs={12} sm={6} md={3} key={item.label}>
            <Paper
              elevation={0}
              sx={{
                border: "1px solid #e5e7eb",
                borderRadius: 2,
                p: 2,
                background: "#f8fafc",
                height: "100%",
                display: "grid",
                alignContent: "start",
                gap: 1,
              }}
            >
              <Typography variant="overline" color="text.secondary" display="block">
                {item.label}
              </Typography>
              <Typography variant="subtitle1" fontWeight={700}>
                {item.value}
              </Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>
    </Container>
  );
}

