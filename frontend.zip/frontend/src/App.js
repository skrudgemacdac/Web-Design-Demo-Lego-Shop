import React from "react";
import Header from "./components/Header/Header";
import Home from "./pages/Home";
import Checkout from "./pages/Checkout";
import ProductDetail from "./pages/ProductDetail";
import Wishlist from "./pages/Wishlist";
import About from "./pages/About";
import Contacts from "./pages/Contacts";
import Register from "./pages/Register";
import { CartProvider } from "./context/CartContext";
import { WishlistProvider } from "./context/WishlistContext";
import { SearchProvider } from "./context/SearchContext";
import { Routes, Route } from "react-router-dom";

import "./App.css";

function App() {
  return (
    <CartProvider>
      <WishlistProvider>
        <SearchProvider>
          <Header />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/checkout" element={<Checkout />} />
            <Route path="/wishlist" element={<Wishlist />} />
            <Route path="/about" element={<About />} />
            <Route path="/contacts" element={<Contacts />} />
            <Route path="/register" element={<Register />} />
            <Route path="/products/:id" element={<ProductDetail />} />
          </Routes>
        </SearchProvider>
      </WishlistProvider>
    </CartProvider>
  );
}

export default App;
